def idiot(rus, y):
    for i in rus:
        diy = i * y
    return diy